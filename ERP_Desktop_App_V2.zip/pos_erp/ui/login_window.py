from PySide6.QtWidgets import (
    QWidget, QLabel, QLineEdit, QPushButton, QVBoxLayout, QHBoxLayout, QMessageBox, QFrame, QCheckBox
)
from PySide6.QtCore import Qt
from pos_erp.services.auth_service import AuthService
from pos_erp.ui.styles import LIGHT_THEME

class LoginWindow(QWidget):
    def __init__(self, on_login_success):
        super().__init__()
        self.on_login_success = on_login_success
        self.init_ui()

    def init_ui(self):
        self.setWindowTitle("Smart POS & ERP - Login")
        self.resize(500, 550)
        self.setStyleSheet(LIGHT_THEME)
        self.setWindowFlags(Qt.Window | Qt.CustomizeWindowHint | Qt.WindowTitleHint | Qt.WindowCloseButtonHint)
        
        main_layout = QVBoxLayout(self)
        main_layout.setAlignment(Qt.AlignCenter)

        card = QFrame()
        card.setObjectName("Card")
        card.setFixedWidth(400)
        card_layout = QVBoxLayout(card)
        card_layout.setContentsMargins(40, 50, 40, 50)
        card_layout.setSpacing(20)

        # Logo
        logo = QLabel("⚡")
        logo.setStyleSheet("font-size: 48px; color: #4f46e5; background: transparent;")
        logo.setAlignment(Qt.AlignCenter)
        card_layout.addWidget(logo)

        title = QLabel("مرحباً بك مجدداً")
        title.setProperty("cssClass", "view-title")
        title.setAlignment(Qt.AlignCenter)
        card_layout.addWidget(title)

        subtitle = QLabel("قم بتسجيل الدخول للمتابعة إلى لوحة التحكم")
        subtitle.setProperty("cssClass", "card-title")
        subtitle.setAlignment(Qt.AlignCenter)
        card_layout.addWidget(subtitle)
        card_layout.addSpacing(10)

        self.username_input = QLineEdit()
        self.username_input.setPlaceholderText("اسم المستخدم (admin)")
        self.username_input.setFixedHeight(45)
        
        self.password_input = QLineEdit()
        self.password_input.setPlaceholderText("كلمة المرور (admin123)")
        self.password_input.setEchoMode(QLineEdit.Password)
        self.password_input.setFixedHeight(45)

        self.username_input.returnPressed.connect(self.password_input.setFocus)
        self.password_input.returnPressed.connect(self.handle_login)

        card_layout.addWidget(self.username_input)
        card_layout.addWidget(self.password_input)

        self.show_pass_cb = QCheckBox("إظهار كلمة المرور")
        self.show_pass_cb.setStyleSheet("color: #4b5563; background: transparent;")
        self.show_pass_cb.stateChanged.connect(self.toggle_password)
        card_layout.addWidget(self.show_pass_cb)
        
        card_layout.addSpacing(10)

        self.login_btn = QPushButton("تسجيل الدخول")
        self.login_btn.setProperty("cssClass", "primary")
        self.login_btn.setFixedHeight(45)
        self.login_btn.setCursor(Qt.PointingHandCursor)
        self.login_btn.clicked.connect(self.handle_login)
        card_layout.addWidget(self.login_btn)

        main_layout.addWidget(card)

    def toggle_password(self, state):
        if state == Qt.Checked.value:
            self.password_input.setEchoMode(QLineEdit.Normal)
        else:
            self.password_input.setEchoMode(QLineEdit.Password)

    def handle_login(self):
        username = self.username_input.text().strip()
        password = self.password_input.text().strip()

        if not username or not password:
            QMessageBox.warning(self, "تنبيه", "يرجى إدخال اسم المستخدم وكلمة المرور")
            return

        user, msg = AuthService.authenticate(username, password)
        if user:
            self.on_login_success(user)
        else:
            QMessageBox.critical(self, "خطأ في تسجيل الدخول", msg)
