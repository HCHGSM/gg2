from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QTableWidget, QTableWidgetItem, QHeaderView, QPushButton, QLineEdit, QSplitter, QGridLayout, QComboBox, QDoubleSpinBox, QFrame, QScrollArea
)
from PySide6.QtCore import Qt
from PySide6.QtWidgets import QMessageBox
from pos_erp.services.product_service import ProductService
from pos_erp.services.sales_service import SalesService

class POSView(QWidget):
    def __init__(self, current_user):
        super().__init__()
        self.current_user = current_user
        self.cart_items = []
        self.all_products = []
        self.init_ui()

    def init_ui(self):
        main_layout = QHBoxLayout(self)
        main_layout.setContentsMargins(15, 15, 15, 15)
        main_layout.setSpacing(15)

        splitter = QSplitter(Qt.Horizontal)

        # --- Left Side: Products Grid ---
        products_widget = QWidget()
        products_layout = QVBoxLayout(products_widget)
        products_layout.setContentsMargins(0, 0, 0, 0)
        
        title = QLabel("نقطة البيع السريع")
        title.setProperty("cssClass", "view-title")
        products_layout.addWidget(title)

        search_layout = QHBoxLayout()
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("🔍 ابحث بالاسم أو الباركود...")
        self.search_input.textChanged.connect(self.filter_products)
        search_layout.addWidget(self.search_input)
        products_layout.addLayout(search_layout)

        self.products_table = QTableWidget()
        self.products_table.setColumnCount(4)
        self.products_table.setHorizontalHeaderLabels(["المنتج", "السعر", "المخزون", "إضافة"])
        self.products_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.products_table.setAlternatingRowColors(True)
        self.products_table.verticalHeader().setVisible(False)
        self.products_table.setShowGrid(False)
        products_layout.addWidget(self.products_table)

        splitter.addWidget(products_widget)

        # --- Right Side: Cart ---
        cart_frame = QFrame()
        cart_frame.setObjectName("Card")
        cart_layout = QVBoxLayout(cart_frame)
        cart_layout.setContentsMargins(20, 20, 20, 20)
        cart_layout.setSpacing(15)

        cart_title = QLabel("سلة المشتريات 🛒")
        cart_title.setProperty("cssClass", "card-title")
        cart_title.setStyleSheet("font-size: 18px; font-weight: bold; color: #111827;")
        cart_layout.addWidget(cart_title)

        self.cart_table = QTableWidget()
        self.cart_table.setColumnCount(5)
        self.cart_table.setHorizontalHeaderLabels(["المنتج", "السعر", "الكمية", "الإجمالي", "إزالة"])
        self.cart_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.cart_table.setAlternatingRowColors(True)
        self.cart_table.verticalHeader().setVisible(False)
        self.cart_table.setShowGrid(False)
        cart_layout.addWidget(self.cart_table)

        # Totals Card
        totals_card = QFrame()
        totals_card.setObjectName("TotalsCard")
        totals_layout = QVBoxLayout(totals_card)
        totals_layout.setContentsMargins(15, 15, 15, 15)

        self.lbl_subtotal = QLabel("المجموع الفرعي: 0.00 ج.س")
        self.lbl_subtotal.setStyleSheet("font-size: 14px; color: #4b5563; background: transparent;")
        
        self.lbl_tax = QLabel("الضريبة (15%): 0.00 ج.س")
        self.lbl_tax.setStyleSheet("font-size: 14px; color: #4b5563; background: transparent;")
        
        self.lbl_total = QLabel("الإجمالي: 0.00 ج.س")
        self.lbl_total.setProperty("cssClass", "card-value")
        self.lbl_total.setStyleSheet("font-size: 24px; font-weight: bold; color: #4f46e5; background: transparent;")

        totals_layout.addWidget(self.lbl_subtotal)
        totals_layout.addWidget(self.lbl_tax)
        totals_layout.addSpacing(10)
        totals_layout.addWidget(self.lbl_total)
        
        cart_layout.addWidget(totals_card)

        # Payment
        pay_layout = QHBoxLayout()
        self.pay_method_combo = QComboBox()
        self.pay_method_combo.addItems(["نقدي (CASH)", "بطاقة بنكية (BANK)"])
        pay_layout.addWidget(QLabel("الدفع:"))
        pay_layout.addWidget(self.pay_method_combo)
        cart_layout.addLayout(pay_layout)

        checkout_btn = QPushButton("إتمام البيع (Checkout)")
        checkout_btn.setProperty("cssClass", "pay-btn")
        checkout_btn.setCursor(Qt.PointingHandCursor)
        checkout_btn.clicked.connect(self.checkout)
        cart_layout.addWidget(checkout_btn)

        splitter.addWidget(cart_frame)
        splitter.setSizes([700, 400])

        main_layout.addWidget(splitter)
        self.load_data()

    def load_data(self):
        self.all_products = ProductService.get_all_products()
        self.filter_products("")

    def filter_products(self, text):
        filtered = [p for p in self.all_products if text.lower() in p.name.lower() or (p.barcode and text in p.barcode)]
        self.populate_products_table(filtered)

    def populate_products_table(self, products):
        self.products_table.setRowCount(0)
        self.products_table.setRowCount(len(products))
        for row, p in enumerate(products):
            self.products_table.setItem(row, 0, QTableWidgetItem(p.name))
            self.products_table.setItem(row, 1, QTableWidgetItem(f"{p.selling_price:,.2f}"))
            self.products_table.setItem(row, 2, QTableWidgetItem(str(p.quantity)))
            
            btn = QPushButton("➕ إضافة")
            btn.setProperty("cssClass", "success")
            btn.setCursor(Qt.PointingHandCursor)
            btn.clicked.connect(lambda checked, prod=p: self.add_to_cart(prod))
            self.products_table.setCellWidget(row, 3, btn)

    def add_to_cart(self, product):
        if product.quantity <= 0:
            QMessageBox.warning(self, "تنبيه مخزون", f"المنتج '{product.name}' نفد تماماً من المخزون!")
            return

        for item in self.cart_items:
            if item['product'].id == product.id:
                if item['quantity'] >= product.quantity:
                    QMessageBox.warning(self, "تنبيه كمية", "لا يمكن إضافة المزيد، الكمية تتجاوز المتاح بالمخزون!")
                    return
                item['quantity'] += 1
                item['tax'] = (item['quantity'] * item['unit_price']) * (product.tax_rate / 100)
                self.update_cart_display()
                return

        tax_amount = product.selling_price * (product.tax_rate / 100)
        self.cart_items.append({
            'product': product,
            'quantity': 1,
            'unit_price': product.selling_price,
            'tax': tax_amount
        })
        self.update_cart_display()

    def update_cart_display(self):
        self.cart_table.setRowCount(0)
        self.cart_table.setRowCount(len(self.cart_items))
        subtotal = 0.0
        tax_total = 0.0

        for row, item in enumerate(self.cart_items):
            p = item['product']
            qty = item['quantity']
            price = item['unit_price']
            total = (qty * price) + item['tax']
            subtotal += qty * price
            tax_total += item['tax']

            self.cart_table.setItem(row, 0, QTableWidgetItem(p.name))
            self.cart_table.setItem(row, 1, QTableWidgetItem(f"{price:,.2f}"))
            self.cart_table.setItem(row, 2, QTableWidgetItem(str(qty)))
            self.cart_table.setItem(row, 3, QTableWidgetItem(f"{total:,.2f}"))

            del_btn = QPushButton("🗑️")
            del_btn.setProperty("cssClass", "danger")
            del_btn.setCursor(Qt.PointingHandCursor)
            del_btn.clicked.connect(lambda checked, r=row: self.remove_from_cart(r))
            self.cart_table.setCellWidget(row, 4, del_btn)

        self.lbl_subtotal.setText(f"المجموع الفرعي: {subtotal:,.2f} ج.س")
        self.lbl_tax.setText(f"الضريبة: {tax_total:,.2f} ج.س")
        self.lbl_total.setText(f"الإجمالي: {subtotal + tax_total:,.2f} ج.س")

    def remove_from_cart(self, row):
        if 0 <= row < len(self.cart_items):
            self.cart_items.pop(row)
            self.update_cart_display()

    def checkout(self):
        if not self.cart_items:
            QMessageBox.warning(self, "سلة فارغة", "يرجى إضافة منتجات إلى السلة أولاً!")
            return

        subtotal = sum(i['quantity'] * i['unit_price'] for i in self.cart_items)
        tax_amount = sum(i['tax'] for i in self.cart_items)
        total = subtotal + tax_amount

        method_text = self.pay_method_combo.currentText()
        payment_method = 'CASH' if 'CASH' in method_text else 'BANK'

        sale_data = {
            'subtotal': subtotal,
            'discount': 0.0,
            'tax_amount': tax_amount,
            'total': total,
            'paid_amount': total,
            'payment_method': payment_method,
            'notes': 'POS Sale'
        }

        items_data = []
        for i in self.cart_items:
            items_data.append({
                'product_id': i['product'].id,
                'quantity': i['quantity'],
                'unit_price': i['unit_price'],
                'discount': 0.0,
                'tax': i['tax']
            })

        success, invoice_no, msg = SalesService.create_sale(sale_data, items_data, self.current_user.id)
        
        if success:
            QMessageBox.information(self, "نجاح", f"تم إتمام الفاتورة بنجاح!\nرقم الفاتورة: {invoice_no}")
            self.cart_items.clear()
            self.update_cart_display()
            self.load_data()
        else:
            QMessageBox.critical(self, "خطأ", f"تعذر إتمام عملية البيع: {msg}")
