
LIGHT_THEME = """
QWidget {
    font-family: 'Segoe UI', 'Cairo', 'Tajawal', system-ui, sans-serif;
    font-size: 14px;
    color: #1f2937;
    background-color: #f9fafb;
}

QMainWindow {
    background-color: #f9fafb;
}

/* Sidebar */
QFrame#Sidebar {
    background-color: #ffffff;
    border-left: 1px solid #e5e7eb;
}

/* Header */
QFrame#Header {
    background-color: #ffffff;
    border-bottom: 1px solid #e5e7eb;
}

/* Cards */
QFrame#Card {
    background-color: #ffffff;
    border: 1px solid #e5e7eb;
    border-radius: 12px;
}

QFrame#TotalsCard {
    background-color: #f3f4f6;
    border: 1px solid #e5e7eb;
    border-radius: 12px;
}

/* Typography */
QLabel[cssClass="view-title"] {
    font-size: 26px;
    font-weight: 800;
    color: #111827;
    background: transparent;
}

QLabel[cssClass="card-title"] {
    font-size: 14px;
    font-weight: 600;
    color: #6b7280;
    background: transparent;
}

QLabel[cssClass="card-value"] {
    font-size: 28px;
    font-weight: 800;
    color: #111827;
    background: transparent;
}

/* Buttons */
QPushButton {
    background-color: #ffffff;
    border: 1px solid #d1d5db;
    border-radius: 8px;
    padding: 8px 16px;
    font-weight: 600;
    color: #374151;
}

QPushButton:hover {
    background-color: #f3f4f6;
    border-color: #9ca3af;
}

QPushButton:pressed {
    background-color: #e5e7eb;
}

QPushButton[cssClass="primary"] {
    background-color: #4f46e5;
    color: #ffffff;
    border: none;
}
QPushButton[cssClass="primary"]:hover {
    background-color: #4338ca;
}

QPushButton[cssClass="success"] {
    background-color: #10b981;
    color: #ffffff;
    border: none;
}
QPushButton[cssClass="success"]:hover {
    background-color: #059669;
}

QPushButton[cssClass="danger"] {
    background-color: #ef4444;
    color: #ffffff;
    border: none;
}
QPushButton[cssClass="danger"]:hover {
    background-color: #dc2626;
}

QPushButton[cssClass="pay-btn"] {
    background-color: #4f46e5;
    color: #ffffff;
    font-size: 18px;
    font-weight: bold;
    padding: 16px;
    border-radius: 8px;
    border: none;
}
QPushButton[cssClass="pay-btn"]:hover {
    background-color: #4338ca;
}

/* Sidebar Buttons */
QPushButton#SidebarBtn {
    text-align: right;
    padding: 12px 16px;
    border: none;
    border-radius: 8px;
    background: transparent;
    font-size: 15px;
    font-weight: 600;
    color: #4b5563;
}
QPushButton#SidebarBtn:hover {
    background-color: #f3f4f6;
    color: #111827;
}
QPushButton#SidebarBtn:checked {
    background-color: #e0e7ff;
    color: #4f46e5;
    font-weight: bold;
}

/* Inputs */
QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox, QTextEdit {
    background-color: #ffffff;
    border: 1px solid #d1d5db;
    border-radius: 8px;
    padding: 8px 12px;
    color: #1f2937;
    selection-background-color: #4f46e5;
}
QLineEdit:focus, QComboBox:focus, QSpinBox:focus, QDoubleSpinBox:focus, QTextEdit:focus {
    border: 2px solid #4f46e5;
    padding: 7px 11px; /* compensate for border width */
}

/* Tables */
QTableWidget {
    background-color: #ffffff;
    border: 1px solid #e5e7eb;
    border-radius: 12px;
    gridline-color: transparent;
    alternate-background-color: #f9fafb;
    selection-background-color: #e0e7ff;
    selection-color: #111827;
    outline: none;
}

QTableWidget::item {
    padding: 12px;
    border-bottom: 1px solid #f3f4f6;
}

QHeaderView::section {
    background-color: #f3f4f6;
    color: #4b5563;
    font-weight: bold;
    padding: 12px;
    border: none;
    border-bottom: 2px solid #e5e7eb;
    text-align: right;
}

/* Scrollbars */
QScrollBar:vertical {
    background: transparent;
    width: 8px;
    margin: 0px;
}
QScrollBar::handle:vertical {
    background: #d1d5db;
    min-height: 20px;
    border-radius: 4px;
}
QScrollBar::handle:vertical:hover {
    background: #9ca3af;
}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
    height: 0px;
}
"""

DARK_THEME = """
QWidget {
    font-family: 'Segoe UI', 'Cairo', 'Tajawal', system-ui, sans-serif;
    font-size: 14px;
    color: #f9fafb;
    background-color: #111827;
}

QMainWindow {
    background-color: #111827;
}

/* Sidebar */
QFrame#Sidebar {
    background-color: #1f2937;
    border-left: 1px solid #374151;
}

/* Header */
QFrame#Header {
    background-color: #1f2937;
    border-bottom: 1px solid #374151;
}

/* Cards */
QFrame#Card {
    background-color: #1f2937;
    border: 1px solid #374151;
    border-radius: 12px;
}

QFrame#TotalsCard {
    background-color: #111827;
    border: 1px solid #374151;
    border-radius: 12px;
}

/* Typography */
QLabel[cssClass="view-title"] {
    font-size: 26px;
    font-weight: 800;
    color: #f9fafb;
    background: transparent;
}

QLabel[cssClass="card-title"] {
    font-size: 14px;
    font-weight: 600;
    color: #9ca3af;
    background: transparent;
}

QLabel[cssClass="card-value"] {
    font-size: 28px;
    font-weight: 800;
    color: #f9fafb;
    background: transparent;
}

/* Buttons */
QPushButton {
    background-color: #374151;
    border: 1px solid #4b5563;
    border-radius: 8px;
    padding: 8px 16px;
    font-weight: 600;
    color: #f9fafb;
}

QPushButton:hover {
    background-color: #4b5563;
    border-color: #6b7280;
}

QPushButton:pressed {
    background-color: #1f2937;
}

QPushButton[cssClass="primary"] {
    background-color: #6366f1;
    color: #ffffff;
    border: none;
}
QPushButton[cssClass="primary"]:hover {
    background-color: #4f46e5;
}

QPushButton[cssClass="success"] {
    background-color: #10b981;
    color: #ffffff;
    border: none;
}
QPushButton[cssClass="success"]:hover {
    background-color: #059669;
}

QPushButton[cssClass="danger"] {
    background-color: #ef4444;
    color: #ffffff;
    border: none;
}
QPushButton[cssClass="danger"]:hover {
    background-color: #dc2626;
}

QPushButton[cssClass="pay-btn"] {
    background-color: #6366f1;
    color: #ffffff;
    font-size: 18px;
    font-weight: bold;
    padding: 16px;
    border-radius: 8px;
    border: none;
}
QPushButton[cssClass="pay-btn"]:hover {
    background-color: #4f46e5;
}

/* Sidebar Buttons */
QPushButton#SidebarBtn {
    text-align: right;
    padding: 12px 16px;
    border: none;
    border-radius: 8px;
    background: transparent;
    font-size: 15px;
    font-weight: 600;
    color: #d1d5db;
}
QPushButton#SidebarBtn:hover {
    background-color: #374151;
    color: #ffffff;
}
QPushButton#SidebarBtn:checked {
    background-color: #3730a3;
    color: #ffffff;
    font-weight: bold;
}

/* Inputs */
QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox, QTextEdit {
    background-color: #1f2937;
    border: 1px solid #4b5563;
    border-radius: 8px;
    padding: 8px 12px;
    color: #f9fafb;
    selection-background-color: #6366f1;
}
QLineEdit:focus, QComboBox:focus, QSpinBox:focus, QDoubleSpinBox:focus, QTextEdit:focus {
    border: 2px solid #6366f1;
    padding: 7px 11px;
}

/* Tables */
QTableWidget {
    background-color: #1f2937;
    border: 1px solid #374151;
    border-radius: 12px;
    gridline-color: transparent;
    alternate-background-color: #111827;
    selection-background-color: #3730a3;
    selection-color: #ffffff;
    outline: none;
}

QTableWidget::item {
    padding: 12px;
    border-bottom: 1px solid #374151;
}

QHeaderView::section {
    background-color: #111827;
    color: #9ca3af;
    font-weight: bold;
    padding: 12px;
    border: none;
    border-bottom: 2px solid #374151;
    text-align: right;
}

/* Scrollbars */
QScrollBar:vertical {
    background: transparent;
    width: 8px;
    margin: 0px;
}
QScrollBar::handle:vertical {
    background: #4b5563;
    min-height: 20px;
    border-radius: 4px;
}
QScrollBar::handle:vertical:hover {
    background: #6b7280;
}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
    height: 0px;
}
"""
