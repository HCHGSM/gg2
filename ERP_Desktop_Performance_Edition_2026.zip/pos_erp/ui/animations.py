import os
from PySide6.QtCore import Qt, QPropertyAnimation, QEasingCurve, QTimer, QVariantAnimation, QSequentialAnimationGroup, QParallelAnimationGroup, QPoint, QRect
from PySide6.QtWidgets import QGraphicsOpacityEffect, QWidget, QLabel, QVBoxLayout, QHBoxLayout, QGraphicsDropShadowEffect
from PySide6.QtGui import QColor

class Animations:
    @staticmethod
    def fade_in(widget, duration=400, easing=QEasingCurve.OutCubic):
        effect = QGraphicsOpacityEffect(widget)
        widget.setGraphicsEffect(effect)
        anim = QPropertyAnimation(effect, b"opacity")
        anim.setDuration(duration)
        anim.setStartValue(0.0)
        anim.setEndValue(1.0)
        anim.setEasingCurve(easing)
        anim.start(QPropertyAnimation.DeleteWhenStopped)
        # Keep reference so it doesn't get garbage collected immediately
        widget._fade_anim = anim 

    @staticmethod
    def fade_out(widget, duration=400, on_finished=None):
        effect = QGraphicsOpacityEffect(widget)
        widget.setGraphicsEffect(effect)
        anim = QPropertyAnimation(effect, b"opacity")
        anim.setDuration(duration)
        anim.setStartValue(1.0)
        anim.setEndValue(0.0)
        anim.setEasingCurve(QEasingCurve.InCubic)
        if on_finished:
            anim.finished.connect(on_finished)
        anim.start(QPropertyAnimation.DeleteWhenStopped)
        widget._fade_anim = anim

    @staticmethod
    def shake(widget):
        anim = QPropertyAnimation(widget, b"pos")
        anim.setDuration(400)
        pos = widget.pos()
        anim.setKeyValueAt(0.0, pos)
        anim.setKeyValueAt(0.1, pos + QPoint(-10, 0))
        anim.setKeyValueAt(0.3, pos + QPoint(10, 0))
        anim.setKeyValueAt(0.5, pos + QPoint(-10, 0))
        anim.setKeyValueAt(0.7, pos + QPoint(10, 0))
        anim.setKeyValueAt(0.9, pos + QPoint(-10, 0))
        anim.setKeyValueAt(1.0, pos)
        anim.start(QPropertyAnimation.DeleteWhenStopped)
        widget._shake_anim = anim

    @staticmethod
    def count_number(label, start_val, end_val, is_float=True, prefix="", suffix="", duration=1000):
        anim = QVariantAnimation(label)
        anim.setDuration(duration)
        anim.setStartValue(float(start_val))
        anim.setEndValue(float(end_val))
        anim.setEasingCurve(QEasingCurve.OutExpo)
        
        def update_text(val):
            if is_float:
                label.setText(f"{prefix}{val:,.2f}{suffix}")
            else:
                label.setText(f"{prefix}{int(val)}{suffix}")
                
        anim.valueChanged.connect(update_text)
        anim.start(QPropertyAnimation.DeleteWhenStopped)
        label._count_anim = anim

    @staticmethod
    def pop_in(widget, duration=500, delay=0):
        # Initial state
        effect = QGraphicsOpacityEffect(widget)
        effect.setOpacity(0)
        widget.setGraphicsEffect(effect)
        
        def start_anim():
            # Opacity
            anim_op = QPropertyAnimation(effect, b"opacity")
            anim_op.setDuration(duration)
            anim_op.setStartValue(0.0)
            anim_op.setEndValue(1.0)
            anim_op.setEasingCurve(QEasingCurve.OutCubic)
            anim_op.start(QPropertyAnimation.DeleteWhenStopped)
            widget._pop_op_anim = anim_op
            
        if delay > 0:
            QTimer.singleShot(delay, start_anim)
        else:
            start_anim()

class Toast(QWidget):
    def __init__(self, parent, message, color="#10B981"):
        super().__init__(parent)
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.Tool | Qt.WindowStaysOnTopHint)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setAttribute(Qt.WA_TransparentForMouseEvents)
        
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        
        frame = QWidget()
        frame.setStyleSheet(f"background-color: {color}; border-radius: 10px;")
        
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(20)
        shadow.setColor(QColor(0,0,0,80))
        shadow.setOffset(0, 5)
        frame.setGraphicsEffect(shadow)
        
        h_layout = QHBoxLayout(frame)
        h_layout.setContentsMargins(20, 15, 20, 15)
        
        lbl = QLabel(message)
        lbl.setStyleSheet("color: white; font-weight: bold; font-size: 15px;")
        h_layout.addWidget(lbl)
        
        layout.addWidget(frame)
        self.adjustSize()

    def show_toast(self, x, y):
        self.move(x, y + 20)
        self.show()
        
        # Slide up and fade in
        self.effect = QGraphicsOpacityEffect(self)
        self.setGraphicsEffect(self.effect)
        
        self.anim_group = QParallelAnimationGroup()
        
        op_anim = QPropertyAnimation(self.effect, b"opacity")
        op_anim.setDuration(300)
        op_anim.setStartValue(0.0)
        op_anim.setEndValue(1.0)
        
        pos_anim = QPropertyAnimation(self, b"pos")
        pos_anim.setDuration(400)
        pos_anim.setStartValue(QPoint(x, y + 20))
        pos_anim.setEndValue(QPoint(x, y))
        pos_anim.setEasingCurve(QEasingCurve.OutBack)
        
        self.anim_group.addAnimation(op_anim)
        self.anim_group.addAnimation(pos_anim)
        self.anim_group.start()
        
        QTimer.singleShot(3000, self.hide_toast)

    def hide_toast(self):
        op_anim = QPropertyAnimation(self.effect, b"opacity")
        op_anim.setDuration(300)
        op_anim.setStartValue(1.0)
        op_anim.setEndValue(0.0)
        op_anim.finished.connect(self.close)
        op_anim.start()
        self._hide_anim = op_anim

class ToastManager:
    @staticmethod
    def show_success(parent, message):
        t = Toast(parent, "✔️ " + message, "#10B981")
        x = parent.width() // 2 - t.width() // 2
        y = parent.height() - 100
        t.show_toast(x, y)

    @staticmethod
    def show_error(parent, message):
        t = Toast(parent, "⚠️ " + message, "#EF4444")
        x = parent.width() // 2 - t.width() // 2
        y = parent.height() - 100
        t.show_toast(x, y)
