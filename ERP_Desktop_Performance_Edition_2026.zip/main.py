import os
import sys
import traceback
from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QIcon, QPixmap
from PySide6.QtWidgets import QApplication, QSplashScreen, QMessageBox
from pos_erp.utils.logger import log_error, log_info

def _resource_path(relative_path):
    """Resolve a bundled resource path whether running from source or from a
    frozen PyInstaller onefile exe (which extracts data to sys._MEIPASS)."""
    base_path = getattr(sys, '_MEIPASS', os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base_path, relative_path)

def global_exception_handler(exctype, value, tb):
    """Catch unhandled exceptions, log them, and show a user-friendly message."""
    error_msg = "".join(traceback.format_exception(exctype, value, tb))
    log_error(f"CRASH: {error_msg}")
    
    # Try to show a dialog if QApplication is running
    if QApplication.instance():
        msg_box = QMessageBox()
        msg_box.setIcon(QMessageBox.Critical)
        msg_box.setWindowTitle("خطأ غير متوقع (System Crash)")
        msg_box.setText("حدث خطأ غير متوقع في النظام.")
        msg_box.setInformativeText("تم تسجيل تفاصيل الخطأ في ملف السجل. يرجى التواصل مع الدعم الفني.")
        msg_box.setDetailedText(error_msg)
        msg_box.exec()
    sys.exit(1)

sys.excepthook = global_exception_handler

def main():
    app = QApplication(sys.argv)
    app.setLayoutDirection(Qt.RightToLeft)

    icon_path = _resource_path(os.path.join('assets', 'icons', 'app_icon.ico'))
    if os.path.exists(icon_path):
        app.setWindowIcon(QIcon(icon_path))

    # Splash Screen
    splash_pix = QPixmap(_resource_path(os.path.join('assets', 'icons', 'app_icon.png')))
    if splash_pix.isNull():
        # Fallback if image not found
        splash_pix = QPixmap(400, 300)
        splash_pix.fill(Qt.white)
        
    splash = QSplashScreen(splash_pix, Qt.WindowStaysOnTopHint)
    splash.show()
    app.processEvents()

    splash.showMessage("جاري تهيئة قاعدة البيانات...", Qt.AlignBottom | Qt.AlignCenter, Qt.black)
    app.processEvents()
    
    # Init DB and seed
    from pos_erp.database.db import init_db
    try:
        init_db()
    except Exception as e:
        log_error(f"DB Init Error: {str(e)}")
        raise e

    splash.showMessage("جاري تحميل واجهة المستخدم...", Qt.AlignBottom | Qt.AlignCenter, Qt.black)
    app.processEvents()

    from pos_erp.ui.login_window import LoginWindow
    from pos_erp.ui.main_window import MainWindow

    main_window = None

    def on_login_success(user):
        nonlocal main_window
        main_window = MainWindow(user)
        main_window.show()

    login_win = LoginWindow(on_login_success)
    
    # Simulate a small delay so user sees splash screen
    def start_app():
        splash.finish(login_win)
        login_win.show()

    QTimer.singleShot(1500, start_app)

    sys.exit(app.exec())

if __name__ == '__main__':
    main()
